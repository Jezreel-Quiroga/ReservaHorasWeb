$(document).ready(function() {

    $(window).load(function() {

        $('#loadOverlay').fadeOut('slow');

    })

})

