export interface HorasReservadas {
    email: string;
    dia: number;
    mes: number;
    anio: number;
    hora: number;
    seleccion: number;
    servicio_contratacion: number;
    servicio_actualizacion: number;
    aceptado: number;
}